<?php

define('LOGIN', array('adm', 'test'));
define('PASSWORD', array('$2y$10$mt./2SLlUi3Bj5r1XD06xerRTM3tPF/bFGj2Yvi2e08MduArZeTqm', '$2y$10$lYQr6Mx9kWDjx9L5nHlwlexo2hJzBPPl/rir/Ej1inYvv27fEJwBe'));
define('KEY', array('$2y$10$C62Zx0rhjvsneLXgIDsi1eFnW5niv/f8MjCfWdlr3/eTIRsOuHnAW', '$2y$10$jua5v/6k/8xLUhQ5fpFv6uQkUugwD0HHL5xAnjG7WfMSvEUa2nwvW'));

// adm, 123, cccccclrnuhn
// password_hash('',PASSWORD_BCRYPT)